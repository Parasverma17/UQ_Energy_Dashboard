//energy breakdown for chemistry building

import ExportButton from "./ExportButton";

export default function BreakdownChart({ data }) {
  if (!data) return null;
  const total = data.reduce((sum, d) => sum + d.value, 0);
  return (
    <div className="w-screen">
        <div className="bg-white rounded-lg shadow p-4 w-360">
        <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg font-bold">Energy Breakdown</h2>
            <ExportButton />
        </div>

        <div className="flex items-end gap-4 h-115">
            {data.map(d => (
            <div key={d.label} className="flex flex-col items-center group">
                <div
                className="w-8 bg-purple-400 rounded-t transition-all duration-200 group-hover:bg-purple-600"
                style={{ height: `${d.value / 10}px` }}
                title={`${d.label}: ${d.value} GJ (${Math.round((d.value / total) * 100)}%)`}
                />
                <span className="text-xs mt-1">{d.label}</span>
                <span className="text-xs text-gray-500">{d.value} GJ</span>
            </div>
            ))}
        </div>
        </div>
    </div>
  );
}

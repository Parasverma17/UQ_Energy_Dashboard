export default function ExportButton() {
  function handleExport() {
    alert("Exported data as CSV/PDF!");
  }
  return (
    <button
      onClick={handleExport}
      className="px-4 py-2 bg-purple-600 text-white rounded-lg font-semibold shadow transition hover:bg-purple-700 float-right"
    >
      Export Data
    </button>
  );
}

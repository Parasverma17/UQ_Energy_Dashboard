export default function Header({ filters, setFilters }) {
  return (
    <div className="flex flex-wrap gap-4 items-center bg-white rounded-lg shadow px-6 py-4 mb-6">
      <input
        type="date"
        value={filters.startDate}
        onChange={e => setFilters(f => ({ ...f, startDate: e.target.value }))}
        className="border rounded px-2 py-1"
      />
      <span>-</span>
      <input
        type="date"
        value={filters.endDate}
        onChange={e => setFilters(f => ({ ...f, endDate: e.target.value }))}
        className="border rounded px-2 py-1"
      />
      <select
        value={filters.resource}
        onChange={e => setFilters(f => ({ ...f, resource: e.target.value }))}
        className="border rounded px-2 py-1"
      >
        <option>Electricity</option>
        <option>Gas</option>
        <option>Water</option>
      </select>
      <select
        value={filters.campus}
        onChange={e => setFilters(f => ({ ...f, campus: e.target.value }))}
        className="border rounded px-2 py-1"
      >
        <option>St Lucia</option>
        <option>Gatton</option>
        <option>Herston</option>
        <option>Other</option>
      </select>
      <input
        type="text"
        placeholder="Search facilities..."
        value={filters.search}
        onChange={e => setFilters(f => ({ ...f, search: e.target.value }))}
        className="border rounded px-2 py-1 flex-1"
      />
    </div>
  );
}

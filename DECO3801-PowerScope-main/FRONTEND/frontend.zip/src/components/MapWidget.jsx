export default function MapWidget({ facilities, selected, setSelected }) {
  const pins = [
    { name: "Advanced Engineering Building", x: 30, y: 40 },
    { name: "Biological Sciences Library", x: 60, y: 60 },
    { name: "Chemistry Building", x: 80, y: 30 },
    { name: "Duhig Tower", x: 50, y: 80 },
    { name: "Forgan Smith Building", x: 20, y: 70 },
    { name: "Goddard Building", x: 70, y: 50 },
  ];
  return (
    <div className="bg-white rounded-lg shadow p-4 flex flex-col items-center">
      <div className="text-sm font-semibold mb-2">Facility Locations</div>
      <div className="relative w-64 h-40 bg-gray-100 rounded">
        {pins.map(pin => (
          <div
            key={pin.name}
            className={`absolute cursor-pointer transition-all duration-200 ${selected === pin.name ? "bg-purple-600 text-white" : "bg-white text-purple-600"} rounded-full px-2 py-1 text-xs shadow`}
            style={{ left: `${pin.x}%`, top: `${pin.y}%`, transform: "translate(-50%, -50%)" }}
            onClick={() => setSelected(pin.name)}
          >
            {selected === pin.name ? pin.name : ""}
            <span className="inline-block w-2 h-2 rounded-full bg-purple-600 ml-1"></span>
          </div>
        ))}
      </div>
      <div className="flex gap-2 mt-2">
        <button className="px-2 py-1 text-xs rounded bg-purple-100 hover:bg-purple-200">Map</button>
        <button className="px-2 py-1 text-xs rounded bg-gray-100 hover:bg-gray-200">Satellite</button>
      </div>
    </div>
  );
}

export default function MetricCard({ title, value, change, changeType, unit }) {
  const color = changeType === "up" ? "text-green-600" : "text-red-600";
  const arrow = changeType === "up" ? "▲" : "▼";
  return (
    <div className="bg-white rounded-lg shadow p-4 flex-1 min-w-[180px]">
      <div className="text-xs text-gray-500">{title}</div>
      <div className="text-2xl font-bold">
        {value}{unit && <span className="text-base font-normal text-gray-600"> {unit}</span>}
      </div>
      <div className={`text-xs ${color}`}>{arrow} {change} YTD vs prior year</div>
    </div>
  );
}

export default function MonthlyChart({ data, selectedMonth, setSelectedMonth }) {
  return (
    <div className="bg-white rounded-lg shadow p-4">
      <div className="text-sm font-semibold mb-2">Monthly Energy Usage Comparison</div>
      <div className="flex gap-2 mb-2 text-xs text-gray-500">
        <span className="font-bold">2023/2024</span>
        <span className="font-bold">2024/2025</span>
      </div>
      <div className="flex items-end gap-2 h-40">
        {data.map((d, idx) => (
          <div key={d.month} className="flex flex-col items-center cursor-pointer group"
            onClick={() => setSelectedMonth(d.month)}>
            <div className={`w-6 rounded-t bg-purple-300 transition-all duration-200 ${selectedMonth === d.month ? "scale-110 bg-purple-500" : ""}`}
              style={{ height: `${d["2023/2024"] / 10}px` }} />
            <div className={`w-6 rounded-t bg-blue-300 transition-all duration-200 ${selectedMonth === d.month ? "scale-110 bg-blue-500" : ""}`}
              style={{ height: `${d["2024/2025"] / 10}px` }} />
            <span className="text-xs mt-1">{d.month}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
